package com.neonbeat.visualizer

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.RemoteViews
import kotlin.math.sin

class VisualizerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        updateOne(context, manager, appWidgetId)
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, VisualizerWidget::class.java))
                .forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("neonbeat", Context.MODE_PRIVATE)
            val options = manager.getAppWidgetOptions(id)
            val minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110).coerceAtLeast(90)
            val maxH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 90).coerceAtLeast(48)
            // Heuristic size classification: launchers report dimensions in dp, but exact cells vary.
            val profile = when {
                minW < 150 -> "small"
                minW < 260 -> "medium"
                else -> "large"
            }
            fun pFloat(key: String, fallback: Float) =
                prefs.getFloat("profile_${profile}_${key}", fallback)
            fun pBoolean(key: String, fallback: Boolean) =
                prefs.getBoolean("profile_${profile}_${key}", fallback)
            fun pString(key: String, fallback: String) =
                prefs.getString("profile_${profile}_${key}", fallback) ?: fallback

            // Render resolution follows the actual widget dimensions. Android scales the bitmap
            // to the launcher cell size, so small and wide widgets stay crisp without fixed sizing.
            val width = (minW * 3).coerceIn(300, 1200)
            val height = (maxH * 3).coerceIn(144, 600)
            val count = pFloat("bars", 42f).toInt().coerceIn(4, 100)
            val thick = pFloat("thickness", .65f).coerceIn(.1f, 1f)
            val spacing = pFloat("spacing", .25f).coerceIn(0f, 1f)
            val opacity = pFloat("opacity", .85f).coerceIn(.1f, 1f)
            val level = prefs.getFloat("level", .12f).coerceIn(0f, 1f)
            val effectHeight = pFloat("height", .8f).coerceIn(.2f, 1f)
            val roundness = pFloat("roundness", .7f).coerceIn(0f, 1f)
            val mirror = pBoolean("mirror", false)

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(android.graphics.Color.TRANSPARENT)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val gap = width.toFloat() / count * spacing
            val barW = ((width.toFloat() - gap * (count - 1)) / count) * thick

            val palette = pString("palette", "Циан / фиолетовый")
            val c1 = when (palette) {
                "Огонь" -> android.graphics.Color.rgb(255, 209, 102)
                "Лёд" -> android.graphics.Color.rgb(224, 255, 255)
                "Розовый" -> android.graphics.Color.rgb(255, 154, 213)
                "Зелёный" -> android.graphics.Color.rgb(184, 255, 106)
                "Белый" -> android.graphics.Color.WHITE
                else -> android.graphics.Color.rgb(84, 231, 240)
            }
            val c2 = when (palette) {
                "Огонь" -> android.graphics.Color.rgb(255, 90, 54)
                "Лёд" -> android.graphics.Color.rgb(74, 168, 255)
                "Розовый" -> android.graphics.Color.rgb(180, 76, 255)
                "Зелёный" -> android.graphics.Color.rgb(22, 199, 132)
                "Белый" -> android.graphics.Color.LTGRAY
                else -> android.graphics.Color.rgb(179, 124, 255)
            }
            paint.shader = android.graphics.LinearGradient(
                0f, 0f, 0f, height.toFloat(), c1, c2, android.graphics.Shader.TileMode.CLAMP
            )
            paint.alpha = (opacity * 255).toInt()

            val centerY = height / 2f
            val maxBarHeight = height * effectHeight
            val phase = System.currentTimeMillis() / 850.0
            for (i in 0 until count) {
                val wave = (sin(i * .52 + phase) * .5 + .5).toFloat()
                val audio = (.12f + level * .88f)
                val h = (maxBarHeight * (.10f + wave * .35f) * audio).coerceAtLeast(height * .035f)
                val x = i * (width.toFloat() / count) + (width.toFloat() / count - barW) / 2
                val top = if (mirror) centerY - h / 2 else centerY - h / 2
                val bottom = centerY + h / 2
                val radius = barW * (.05f + roundness * .45f)
                canvas.drawRoundRect(RectF(x, top, x + barW, bottom), radius, radius, paint)
            }

            val views = RemoteViews(context.packageName, R.layout.widget_visualizer)
            views.setImageViewBitmap(R.id.widget_bars, bitmap)
            manager.updateAppWidget(id, views)
        }
    }
}
